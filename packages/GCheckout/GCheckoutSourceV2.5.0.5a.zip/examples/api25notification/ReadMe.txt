﻿This example shows how to implement a notification callback for the v2.5 api.

original source from:

http://www.capprime.com/software_development_weblog/2010/11/29/UsingTheGoogleCheckout25APIWithASPNETMVCTheMissingSample.aspx