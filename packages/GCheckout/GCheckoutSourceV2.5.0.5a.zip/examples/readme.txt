This folder contains example code. None of the code is needed to integrate with 
Google Checkout. None of the code is compiled into GCheckout.dll. Read the 
readme files in each sub-directory to learn about the example code.
