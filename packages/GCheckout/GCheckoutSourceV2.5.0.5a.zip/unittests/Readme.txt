You must use GoogleCheckoutUnitTests.nunit

If you do not do this, the Config unit tests will fail.

You must unzip the lib and the unit tests on the same level or GoogleCheckoutUnitTests.sln will not find both csproj files.

Example:

Root
  lib
  unittests
  examples


Please unzip CodeReport.zip and open index.html to view the Code Coverage Reports.

Joe Feser